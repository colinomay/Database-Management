﻿----------------------------------------------------------------------------------------
-- Postgres create, load, and query script for May's Bookstore.
-- SQL statements for the May's Bookstore database
-- Modified several times by Colin May
-----------------------------
drop view if exists bookInfo; 
drop view if exists receipt;
drop view if exists projectedQuantity;
DROP TABLE IF EXISTS orderDetails;
DROP TABLE IF EXISTS orders;
DROP TABLE IF EXISTS employee;
DROP TABLE IF EXISTS inventory;
DROP TABLE IF EXISTS bookstore;
DROP TABLE IF EXISTS customer;
DROP TABLE IF EXISTS supplies;
DROP TABLE IF EXISTS book;
DROP TABLE IF EXISTS supplier;
DROP TABLE IF EXISTS author;
DROP TABLE IF EXISTS genre;
drop function if exists storeInventoryInfo(integer, refcursor); 
drop function if exists checkInventory(refcursor);
drop trigger if exists inventoryCheck on orderDetails;
drop trigger if exists showInventory on orderDetails;


-- Author --
CREATE TABLE author (
  author_id		SERIAL,
  author_name 	text not null,
 primary key(author_id)
);

-- Genre --
CREATE TABLE genre (
 genre_id		SERIAL,
 genre_name		text not null,
 primary key(genre_id)
);

-- Supplier --
CREATE TABLE supplier (
 supplier_id		SERIAL,
 supplier_name		text not null,
 city				text not null,
 state				text not null,	
 phone_number		text,
 primary key(supplier_id)
);

-- Book --
CREATE TABLE book (
 book_id			SERIAL,
 author_id			integer not null references author(author_id),
 genre_id			integer	not null references genre(genre_id),
 title				text not null,
 ISBN				text,
 primary key(book_id)
);

-- Supplies --
CREATE TABLE supplies (
  supplier_id 		integer not null references supplier(supplier_id),
  book_id			integer not null references book(book_id),
  quantity_bought	integer not null CHECK (quantity_bought>0),
 primary key(supplier_id,book_id)
);

-- Customer --
CREATE TABLE customer (
  customer_id		SERIAL,
  first_name		text not null,
  last_name			text not null,
  address			text not null,
  city				text not null,
  state				text not null,
  postal_code 		text not null,
  email_address		text,
 primary key(customer_id)
);

-- Bookstore --
CREATE TABLE bookstore (
 store_id 			SERIAL,
 location			text not null,
 phone_number		text not null,
 primary key(store_id)
);

-- Inventory --
CREATE TABLE inventory (
 book_id			integer not null references book(book_id),
 store_id			integer not null references bookstore(store_id),
 quantity			integer not null CHECK (quantity>0) ,
 unit_price_usd	numeric(12,2) not null CHECK (unit_price_usd>0), 
 primary key(book_id,store_id)
);

-- Employee --
CREATE TABLE employee (
  employee_id   	SERIAL,
  store_id			integer not null references bookstore(store_id),
  first_name		text not null,
  last_name			text not null,
  address			text not null,
  city				text not null,
  state				text not null,
  postal_code 		text not null,
  hired_date		date,
  position			text,
 primary key(employee_id)
);

-- Orders --
CREATE TABLE orders (
 order_id			SERIAL,
 customer_id		integer not null references customer(customer_id),
 employee_id		integer not null references employee(employee_id),
 order_date			timestamp not null,
 primary key(order_id)
);

-- Order Details --
CREATE TABLE orderDetails (
 order_id			integer not null references orders(order_id),
 book_id			integer not null references book(book_id),
 store_id			integer not null references bookstore(store_id),
 quantity_sold		integer not null CHECK (quantity_sold>0),
 primary key(order_id,book_id)
);

-----------------------------------------------------------

-- SQL statements for loading example data into the May's Bookstore database

-- Genre --
INSERT INTO genre(genre_name)
VALUES('Science fiction'),('Crime'),('Classic'),('Historical fiction'),('Comedy'),('Drama'),('Action'),
('Romance'),('Mystery'),('Horror'),('Fantasy'),('Realistic fiction');
  
INSERT INTO author(author_name)
VALUES('Agatha Christie'),('Anthony Horowitz'),('S.E. Hinton'),('John Green'),('Gillian Flynn'),
('Toni Morrison'),('Ernest Cline'),('Stieg Larsson'),('Douglas Adams'),('Markus Zusak'),('J.K. Rowling'),
('Harper Lee'),('Arthur Conan Doyle'),('Jane Austen'),('Andy Weir'),('F. Scott Fitzgerald'),('Dan Brown'),
('Michael Connelly'),('Hugh Howey'),('Robert Masello'),('Anthony Doerr'),('Jules Verne'),('Herman Melville'),
('Mark Edwards'),('Paula Hawkins'),('Emily BrontÎ');

INSERT INTO book(title,author_id,genre_id,ISBN)
VALUES('And Then There Were None',1,2,'978-0062073488'),
('The Outsiders',3,12,'978-0142407332'),
('The Girl on the Train',25,9,'978-1594634024'),
('Paper Towns',4,12,'978-0142414934'),
('Ready Player One: A Novel',7,1,'978-0307887443'),
('All the Light We Cannot See',21,4,'978-1501132872'),
('The Hitchhikers Guide to the Galaxy',9,5,'978-0345391803'),
('The Book Thief',10,4,'978-0375842207'),
('Home',6,4,'978-0307594167'),
('Moby Dick',23,3,'978-1503280786'),
('Rumble Fish',3,12,'978-0385375689'),
('Harry Potter and the Prisoner of Azkaban',11,11,'978-0439136365'),
('To Kill a Mockingbird',12,3,'978-0446310789'),
('Gone Girl',5,6,'978-0307588371'),
('The Hound of the Baskervilles',13,2,'978-0486282145'),
('Wuthering Heights',26,8,'978-1853260018'),
('Stormbreaker',2,7,'978-0142406113'),
('Pride and Prejudice',14,8,'978-0486284736'),
('The Fault in Our Stars',4,8,'978-0142424179'),
('The Martian',15,1,'978-0553418026'),
('Around the World in 80 Days',22,5,'978-1503215153'),
('The Great Gatsby',16,6,'978-0743273565'),
('The Girl with the Dragon Tattoo',8,2,'978-0307949486'),
('Inferno',17,9,'978-1400079155'),
('The Lincoln Lawyer',18,9,'978-1455567386'),
('Wool',19,1,'978-1476733951'),
('The Einstein Prophecy',20,7,'978-1477829400'),
('Follow You Home',24,10,'978-1503944374'),
('Journey to the Center of the Earth',22,3,'978-1505573947'),
('Harry Potter And The Chamber Of Secrets',11,11,'978-0439064873');

INSERT INTO supplier(supplier_name,city,state,phone_number)
VALUES('Amazon','Seattle','WA','206-266-1000'),
('Barnes & Nobles','New York City','NY','212-633-3300'),
('Ebay','San Jose','CA','408-376-7514'),
('Powells Books','Portland','OR','503-228-4651'),
('Thrift Books','Auburn','WA','312-581-2204');

INSERT INTO supplies(supplier_id,book_id,quantity_bought)
VALUES(3,12,5),(4,3,7),(2,18,4),(3,23,3),(3,19,2),(5,24,6),(2,9,2),(1,2,10),(1,8,8),(4,1,9),(1,7,7),
(5,26,5),(2,17,9),(5,18,3),(1,3,1);

INSERT INTO customer(first_name,last_name,address,city,state,postal_code,email_address)
VALUES('Chelsea','Stacey','590 Valley View St.','Old Bridge','NJ','08857','chelseas123@gmail.com'),
('Therese','Clemens','621 E. Oak Avenue','Tualatin','NY','97062','tclemens@yahoo.com'),
('Walker','Willoughby','373 West Dr.','Oceanside','NY','11572','walkerwilloughby246@icloud.com'),
('Tristan','Roberts','44 Newport Road','Newport','CT','23601','troberts32@gmail.com'),
('Daniel','Sniders','357 Creekside Lane','Victoria','CT','79904','sniders.dan@yahoo.com'),
('Nathan','Larson','67 West Tower St.','Asheboro','MA','27206',null),
('Anna','Scott','12 Windsor St.','Mesa','MA','85203','anna.scott135@gmail.com'),
('Izzie','Collins','1776 Hamilton Court','Danvers','NJ','36321', null);

INSERT INTO bookstore(location,phone_number)
VALUES('Thorton,NY','473-682-9526'),('Plainview,MA','527-158-1914'),('Willsboro,CT','723-650-0162');

INSERT INTO inventory(book_id,store_id,quantity,unit_price_usd)
VALUES(23,2,4,5.99),(12,1,4,3.99),(9,1,5,7.99),(22,2,4,6.99),(13,1,9,7.99),(1,2,8,4.99),
(4,3,3,5.99), (5,2,5,4.99),(10,3,8,4.99),(17,1,7,3.99),(11,3,9,5.99),(21,2,4,5.99),(27,3,8,4.99),
(6,2,6,5.99),(18,1,5,4.99),(3,3,9,4.99),(14,1,4,5.99),(25,2,9,7.99),(7,2,7,6.99),(15,3,3,3.99),
(29,1,5,6.99),(28,2,8,7.99),(24,3,8,4.99),(19,3,3,6.99),(30,2,3,6.99),(26,2,7,5.99),(20,1,7,4.99),
(2,2,4,7.99),(8,3,5,4.99),(16,2,6,5.99);

INSERT INTO employee(store_id,first_name,last_name,address,city,state,postal_code,hired_date,position)
VALUES(1,'Manny','Davis','429 Water Drive','Oak Park','NY','48237','2014-4-15','Cashier'),
(1,'Kurt','Rogers','42 E. Market Street','Fair Lawn','NY','54932','2002-8-28','Manager'),
(2,'Rosa','Danielson','22 Brookside Drive','Simpsonville','MA','68192','2015-2-11','Cashier'),
(2,'Herbert','Baines','238 Bayberry Street','Paterson','MA','32823','2008-5-8','Cashier'),
(3,'Kelly','Roberts','732 Edgewood St.','Middletown','CT','42153','2010-6-23','Cashier'),
(3,'Nicki','Wilson','34 Sierra Rd.','Torrington','CT','13642','2005-1-3','Cashier');

INSERT INTO orders(customer_id,employee_id,order_date)
VALUES(2,1,'2016-12-5 12:13:11'),(1,2,'2016-12-6 10:48:51'),(7,3,'2016-12-3 14:28:32'),
(5,3,'2016-11-28 15:53:17'),(3,2,'2016-12-3 13:23:54'),(4,4,'2016-12-2 11:30:37'),
(6,5,'2016-11-29 9:46:38'),(8,6,'2016-11-25 16:05:20');

INSERT INTO orderDetails(order_id,book_id,store_id,quantity_sold)
VALUES(1,20,1,3),(1,29,1,1),(1,10,1,2),(2,3,1,1),(3,9,2,3),(3,22,2,2),(4,23,2,1),(4,24,2,2),
(5,1,1,1),(6,6,2,3),(7,20,3,1),(7,9,3,1),(7,28,3,2),(7,13,3,2),(8,17,3,3),(8,7,3,4);

-----------------------------------------------------------

-- SQL statements for views of the May's Bookstore database-----

 create view receipt as
  select orderDetails.order_id, customer.first_name as customer_first, customer.last_name as customer_last, employee.first_name as employee_first,employee.last_name as employee_last,
  book.title,orderDetails.store_id, orderDetails.quantity_sold,inventory.unit_price_usd,  orderDetails.quantity_sold*inventory.unit_price_usd as cost_usd, orders.order_date
  from orderDetails inner join orders on orders.order_id = orderDetails.order_id
		   inner join employee on employee.employee_id = orders.employee_id
		   inner join customer on customer.customer_id = orders.customer_id
		   inner join book on book.book_id = orderDetails.book_id
		   inner join inventory on orderDetails.book_id = inventory.book_id
order by orders.order_id;
 --------------------------------------------------------------------------------------------------
 create view bookInfo as
  select book.book_id, book.title, author.author_name, genre.genre_name, book.ISBN, inventory.unit_price_usd  
  from book inner join author on book.author_id = author.author_id
	    inner join genre on book.genre_id = genre.genre_id
	    inner join inventory on inventory.book_id = book.book_id
order by book.book_id;
---------------------------------------------------------------------------------------------------
-- SQL reports and interesting queries-----
select orderDetails.store_id,bookstore.location, count(orders.customer_id) as num_lineitems, sum(orderDetails.quantity_sold) as total_books_sold, sum(orderDetails.quantity_sold*inventory.unit_price_usd) as total_revenue
from orderDetails inner join orders on orders.order_id=orderDetails.order_id
		  inner join inventory on orderDetails.book_id = inventory.book_id
		  inner join bookstore on orderDetails.store_id = bookstore.store_id
group by orderDetails.store_id, bookstore.location
order by orderDetails.store_id;
-------------------------------------------------------------------------------------------------------
create view projectedQuantity as
select t3.book_id, title, (coalesce(quantity,0)+coalesce(quantity_bought,0)-coalesce(quantity_sold,0)) as projected_quantity, unit_price_usd
from
	(select supplies.book_id,sum(quantity_bought) as quantity_bought 
	from supplies 
	group by supplies.book_id) t4
right outer join
	(select t1.book_id, title,quantity,unit_price_usd, quantity_sold
	from 
		(select book.book_id,title,quantity,unit_price_usd 
		from book inner join inventory on inventory.book_id = book.book_id) t1 
	left outer join
		(select book_id, sum(quantity_sold) as quantity_sold
		from orders inner join orderDetails on orderDetails.order_id = orders.order_id group by orderDetails.book_id) t2 
		on t1.book_id = t2.book_id
	order by t1.book_id) t3
on t4.book_id=t3.book_id;
---------------------------------------------------------------------------------------
--- SQL store procedures -----
create or replace function storeInventoryInfo(integer, refcursor) returns refcursor as 
$$
declare
   store integer := $1;
   resultset refcursor := $2;
begin
   open resultset for 
      select inventory.store_id,location, inventory.book_id, title, author_name, genre_name, isbn, quantity,unit_price_usd
      from   inventory inner join bookstore on bookstore.store_id = inventory.store_id
			inner join book	on book.book_id = inventory.book_id
			inner join author on book.author_id = author.author_id
			inner join genre on book.genre_id = genre.genre_id
      where  inventory.store_id = store
      order by inventory.book_id;
   return resultset;
end;
$$ 
language plpgsql;
-----------------------------------------------------------------------------------------------------

create or replace function checkInventory(refcursor) returns refcursor as
$$
declare
	resultset refcursor :=$1;
begin
   open resultset for 
	select * from projectedQuantity where projected_quantity <= 0;
   return resultset;
end;
$$
language plpgsql;
----------------------------------------------------------------------------------------
-----SQL Triggers and Functions-------------
create or replace function negativeInventory() returns trigger as
$$
begin
	select * from projectedQuantity where projected_quantity <= 0;
   return new;
end;
$$
language plpgsql;
-------
create trigger inventoryCheck
after update of quantity_sold or insert
on orderDetails
for each row
execute procedure negativeInventory();
-------------------------------------------
create or replace function currentInventory() returns trigger as
$$
begin 
select * from projectedQuantity;
return new;
end;
$$
language plpgsql;
-------
create trigger showInventory
after update or insert
on inventory
for each row
execute procedure currentInventory();
-------------------------------------------------
