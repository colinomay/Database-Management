﻿drop table if exists directing;
drop table if exists acting;
drop table if exists movies;
drop table if exists directors;
drop table if exists actors;
drop table if exists people;

CREATE TABLE people (
	pid 			SERIAL,
	name			text,
	address			text,
	spouse			text,
	birthdate		date,
	primary key(pid)
);

CREATE TABLE directors(
	pid 			integer not null references people(pid),
	school_attended		text,
	lensmaker		text,
	primary key (pid)
);

CREATE TABLE actors(
	pid 			integer not null references people(pid), 	
	hairColor		text,
	eyeColor		text,
	height_in		int,
	weight_pounds		int,
	color_fav		text,
	primary key (pid)
);

CREATE TABLE movies(
	mid			SERIAL,
	name	 		text,
	release_date	 	date,
	MPAA			text,
	length_minutes		int,
	primary key(mid)
);

CREATE TABLE acting(
	pid 		integer not null references people(pid),
	mid 		integer not null references movies(mid),
	primary key(pid,mid)
);

CREATE TABLE directing(
	pid 		integer not null references people(pid),
	mid 		integer not null references movies(mid),
	primary key(pid,mid)
);

--Movies--
INSERT INTO movies(name,release_date,MPAA,length_minutes)
VALUES ('Good Will Hunting','1997-12-5','R',126),
('Never Say Never Again','1983-10-7','PG',134),
('The Santa Clause','1994-11-11','PG',97),
('Pink Panther', '2006-2-10','PG',93),
('Zoolander','2001-9-28','PG-13',89),
('Goldfinger','1964-9-18','PG-13',110);

--People--
INSERT INTO people(name, address, spouse,birthdate)
VALUES ('Robin Williams','Chicago, Illinois','Susan Schneider','1951-7-21'),
('Sean Connery','Fountainbridge, Edinburgh', 'Micheline Roquebrune','1930-8-25'),
('Irvin Kershner', 'Philadelphia, Pennsylvania',Null,'1923-4-29'),
('Gus Van Sant', 'Louisville, Kentucky',Null,'1952-7-24'),
('Tim Allen','Denver, Colorado', 'Jane Hajduk','1953-6-13'),
('John Pasquin','Houston, TX', 'JoBeth Williams', '1944-11-30'),
('Steve Martin','Waco, Texas','Anne Stringfield', '1945-8-14'),
('Shawn Levy', 'Montreal, Quebec','Serena','1968-7-23'),
('Ben Stiller','New York City, New York','Christine Taylor','1965-11-30'),
('Guy Hamilton','Paris, France','Kerima', '1922-9-16');

--Actors--
INSERT INTO actors(pid,hairColor,eyeColor,height_in,weight_pounds,color_fav)
VALUES (1,'brown','green',67,170,'purple'),
(2,'black','brown',74,190,'blue'),
(5, 'brown', 'blue',71,182,'black'),
(7, 'white', 'brown',72, 165,'red'),
(9, 'black','blue',67,150,'yellow');

--Directors--
INSERT INTO directors(pid,school_attended,lensmaker)
VALUES (3,'University of Southern California','Olympus Corporation‎'),
(4,'Rhode Island School of Design','Samsung'),
(6,'Carnegie Mellon University', 'Nikon'),
(8,'Yale University', 'Leidolf'),
(9,'University of California','Cosina'),
(10,'Victorine Studios', 'Tamron');


--Acting--
INSERT INTO acting(pid,mid)
VALUES (1,1),(2,2),(5,3),(7,4),(9,5),(2,6);

--Directing--
INSERT INTO directing(pid,mid)
VALUES (4,1),(3,2),(6,3),(8,4),(9,5),(10,6);

--Query for Sean Connery----
select people.pid,name,address,spouse,birthdate,school_attended,lensmaker
from directors inner join people on people.pid=directors.pid
where directors.pid in (select pid
			from directing
			where directing.mid in (select acting.mid
						from acting
						where acting.pid in (select actors.pid
					  			     from actors inner join people on actors.pid = people.pid
								     where people.name='Sean Connery'
								     )
						)
			);